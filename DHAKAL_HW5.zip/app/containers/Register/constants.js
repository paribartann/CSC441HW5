
export const REGISTER_USER = 'boilerplate/Register/REGISTER_USER';
export const CHANGE_FIRSTNAME = 'boilerplate/Register/CHANGE_FIRSTNAME';
export const CHANGE_LASTNAME = 'boilerplate/Register/CHANGE_LASTNAME';
export const CHANGE_EMAIL = 'boilerplate/Register/CHANGE_EMAIL';
export const CHANGE_PASSWORD = 'boilerplate/Register/CHANGE_PASSWORD';

