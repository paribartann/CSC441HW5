import styled from 'styled-components';

const Form = styled.form`
  margin-bottom: 1em;
`;

export default Form;
