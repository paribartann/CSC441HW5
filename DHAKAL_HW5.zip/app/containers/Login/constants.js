
export const LOGIN_USER = 'boilerplate/Login/LOGIN_USER';
export const CHANGE_EMAIL = 'boilerplate/Login/CHANGE_EMAIL';
export const CHANGE_PASSWORD = 'boilerplate/Login/CHANGE_PASSWORD';

